#!/usr/bin/env python3

"""
Clase de controlador 2D utilizado para el demo de CARLA waypoint follower
"""

import cutils
import numpy as np

class Controller2D(object):
    def __init__(self, waypoints):
        self.vars                = cutils.CUtils()
        self._current_x          = 0
        self._current_y          = 0
        self._current_yaw        = 0
        self._current_speed      = 0
        self._desired_speed      = 0
        self._current_frame      = 0
        self._current_timestamp  = 0
        self._start_control_loop = False
        self._set_throttle       = 0
        self._set_brake          = 0
        self._set_steer          = 0
        self._waypoints          = waypoints
        self._conv_rad_to_steer  = 180.0 / 70.0 / np.pi
        self._pi                 = np.pi
        self._2pi                = 2.0 * np.pi

    def update_values(self, x, y, yaw, speed, timestamp, frame):
        self._current_x         = x
        self._current_y         = y
        self._current_yaw       = yaw
        self._current_speed     = speed
        self._current_timestamp = timestamp
        self._current_frame     = frame
        if self._current_frame:
            self._start_control_loop = True

    def update_desired_speed(self):
        min_idx       = 0
        min_dist      = float("inf")
        desired_speed = 0
        for i in range(len(self._waypoints)):
            dist = np.linalg.norm(np.array([
                    self._waypoints[i][0] - self._current_x,
                    self._waypoints[i][1] - self._current_y]))
            if dist < min_dist:
                min_dist = dist
                min_idx = i
        if min_idx < len(self._waypoints)-1:
            desired_speed = self._waypoints[min_idx][2]
        else:
            desired_speed = self._waypoints[-1][2]
        self._desired_speed = desired_speed

    def update_waypoints(self, new_waypoints):
        self._waypoints = new_waypoints

    def get_commands(self):
        return self._set_throttle, self._set_steer, self._set_brake

    def set_throttle(self, input_throttle):
        # Ancla la aceleración a un limite valido
        throttle           = np.fmax(np.fmin(input_throttle, 1.0), 0.0)
        self._set_throttle = throttle

    def set_steer(self, input_steer_in_rad):
        # Convierte los radianes a [-1, 1]
        input_steer = self._conv_rad_to_steer * input_steer_in_rad

        # Ancla la direccion a comandos validos
        steer           = np.fmax(np.fmin(input_steer, 1.0), -1.0)
        self._set_steer = steer

    def set_brake(self, input_brake):
        # Ancla la direccion a comadnos validos 
        brake           = np.fmax(np.fmin(input_brake, 1.0), 0.0)
        self._set_brake = brake

    def update_controls(self):
        ######################################################
        # SIMULACION DE FEEDBACK
        ######################################################
        x               = self._current_x
        y               = self._current_y
        yaw             = self._current_yaw
        v               = self._current_speed
        self.update_desired_speed()
        v_desired       = self._desired_speed
        t               = self._current_timestamp
        waypoints       = self._waypoints
        throttle_output = 0
        steer_output    = 0
        brake_output    = 0

        ######################################################
        ######################################################
        # DECLARE EL USO DE VARIABLES AQUI
        ######################################################
        ######################################################
        """
            Usar 'self.vars.create_var(<variable name>, <default value>)'
            para crear una variable persistente (que no se destruya en cada iteracion).
            Significa que el valor puede ser almacenado para uso en la siguiente
            iteracion de lazo de control.

            Ejemplo: Creacion de 'v_previous', valor por defecto a ser 0
            self.vars.create_var('v_previous', 0.0)

            Ejemplo: Creacion de 'v_previous', valor por defecto a ser 1
            self.vars.create_var('v_previous', 1.0)

            Ejemplo: Accediendo al valor de 'v_previous' para ser utilizado
            throttle_output = 0.5 * self.vars.v_previous
        """
        self.vars.create_var('v_previous', 0.0)

        # Pasar por alto la primera trama para conservar valores iniciales
        if self._start_control_loop:
            """
                Iteracion del bloque de control.

                Variables de Feedback del controlador:
                    x               : Posicion X Actual(meters)
                    y               : Posicion Y Actual (meters)
                    yaw             : Rotacion en Z (yaw) actual (radians)
                    v               : Velocidad actual  (m/s)
                    t               : Tiempo actual (segundos)
                    v_desired       : Velocidad deseada (m/s)
                                      (Calculada como la velocidad a seugir en
                                      el waypoint mas cercano del vehiculo.)
                    waypoints       : Puntos a seguir
                                      (Incluye velocidad y puntos x,y)
                                      Formato: [[x0, y0, v0],
                                               [x1, y1, v1],
                                               ...
                                               [xn, yn, vn]]
                                      Ejemplo:
                                          waypoints[2][1]: 
                                          Retorna el 3er waypoint y posicion

                                          waypoints[5]:
                                          Retorna [x5, y5, v5] (6to waypoint)
                
                Variables de control de salida:
                    throttle_output : salida de aceleracion (0 to 1)
                    steer_output    : salida de direccion (-1.22 rad to 1.22 rad)
                    brake_output    : salida de freno (0 to 1)
            """

            ######################################################
            ######################################################
            # Implementacion de control longitudinal
            ######################################################
            ######################################################
            """
                Implemente el control longitudinal aqui. Recuerde que puede
                acceder a data persistente de variables declaradas arriba. Por
                ejemplo, puede ser self.vars.v_previous como "variable global".
            """
            
            # Cambie los controles del controlador longitudinal. Note que el
            # brake_output es opcional y no es requerido pues el carro
            # desacelera sobre el tiempo.
            throttle_output = 0
            brake_output    = 0

            ######################################################
            ######################################################
            # Implementacion de control lateral
            ######################################################
            ######################################################
            """
                Implementar el control lateral aqui. Recuerde que ud puede acceder
                la data persistente de arriba. Por ejemplo
                puede ser tratada como self.vars.v_previous como una "variable global".
            """
            
            # cambiar el controlador de direccion lateral aqui. 
            steer_output    = 0

            ######################################################
            # SET CONTROLS OUTPUT
            ######################################################
            self.set_throttle(throttle_output)  # en porcentaje (0 to 1)
            self.set_steer(steer_output)        # en radianes (-1.22 to 1.22)
            self.set_brake(brake_output)        # en porcentaje (0 to 1)

        ######################################################
        ######################################################
        # ALMACENE VIEJOS VALORES AQUI
        ######################################################
        ######################################################
        """
            Use este bloqeu para almacenar valores antiguos (por ejemplo, se puede almacenar
            el valor x, y, y rotacion en z usando variables de data persistente para su uso
            en la siguiente iteracion)
        """
        self.vars.v_previous = v  # almacenar la velocidad a utilizar en el siguiente ciclo
